## Hooks

This folder contains all of the React hooks that we will use in our app.
