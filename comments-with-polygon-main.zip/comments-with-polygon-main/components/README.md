## Components

This folder contains all of the React components that we will use in our app.
